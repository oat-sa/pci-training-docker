//AMD loader
define(['qtiCustomInteractionContext'], function(qtiCustomInteractionContext) {

    //regsiter the PCI against the bridge
    qtiCustomInteractionContext.register({
    
        // please change the typeIdentifier, it should be unique
        typeIdentifier: 'myAwesomeInteraction',

        /**
         * @param {HTMLElement} dom - the container of the PCI
         * @param {Object} config
         * @param {string} config.status - the item status ('interacting', 'closed', 'suspended', etc.)
         * @param {Object} config.boundTo - the last student answer
         * @param {Object} config.properties
         * @param {Object} config.properties.language - the language of the item, defined by the item author
         * @param {Object} config.properties.userLanguage - the language of the test-taker
         * @param {function} config.onready - callback when the interaction is ready to be rendered by the test taker
         * @param {function} config.ondone - optional callback to inform the item is finished
         */
        getInstance(dom, config, state) {

            console.log('Config', config);
            console.log('State', state);
            console.log('dom', dom);

            let answer = null;

            const myInteraction = {

                getResponse() {

                    return { base : { string : answer } };
                },

                getState() { 

                    return {};
                },

                oncompleted() {
                    console.log('oncompleted called');
                }
            };

            setTimeout(function() { 
            
                //call when the interaction is ready
                config.onready(myInteraction, state);
            
            }, 100);
        }
    });
});
